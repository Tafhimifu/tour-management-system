var guide =[
    {
      "name": "Zayn Malik",
      "AvailableDay": "Fri Sat Sun Mon ",
      "img": "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
    },
    {
      "name": "Namik Paul",
      "AvailableDay": "Tues Wed Thurs ",
      "img": "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80"
    },
    {
      "name": "Song Joong Ki ",
      "AvailableDay": "Fri Sat Sun",
      "img": "https://images.thestar.com/1oAd5WQ5PDUPyJBzdj6icfO1a5w=/605x749/smart/filters:cb(1562848771291)/https://www.thestar.com/content/dam/thestar/news/crime/2019/07/11/toronto-police-release-photo-of-man-arrested-in-eaton-centre-voyeurism-investigation/sohanthen_udayashankar_22.jpg"
    },
    {
      "name": "Ahnaf Abir",
      "AvailableDay": "Mon Tues Wed Thurs",
      "img": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRoKeo8WiWDuVr11oS4G3bmS9lweHKpGuF5mg&usqp=CAU"
    },
    {
      "name": "Zain Imam",
      "AvailableDay": "Thurs Fri Sat",
      "img": "https://kymkemp.com/wp-content/uploads/2019/03/500600p4325EDNmainJohnson_031219.jpg"
    },
    {
      "name": "Yang Yang",
      "AvailableDay": "Sun Mon Tues Thurs",
      "img": "https://ath2.unileverservices.com/wp-content/uploads/sites/8/2019/09/hairstyles-for-men-with-round-faces-modern-quiff.jpg"
    },
    {
      "name": "Na Jae Min",
      "AvailableDay": "Wed Thurs Fri",
      "img": "https://www.mantruckandbus.com/fileadmin/media/bilder/020/mit-18-monaten-planungszeit-stefan-sahlmann-header.jpg"
    },
    {
      "name": "Liu Yuan ",
      "AvailableDay": "Sat Sun Mon Fri",
      "img": "https://i.dlpng.com/static/png/6709284_preview.png"
    },
    {
      "name": "Steven Zhang",
      "AvailableDay": "Tues Wed Thurs",
      "img": "https://www.duraplas.com.au/wp-content/uploads/2015/08/Smiling-young-casual-man-2.png"
    },
    {
      "name": "Choi Bo Min",
      "AvailableDay": "Fri Sat Sun",
      "img": "https://directplusnow.com/wp/wp-content/uploads/2013/09/smilingMan-b.png"
    },
    {
      "name": "Randeep Rai",
      "AvailableDay": "Mon Tues Wed Thurs",
      "img": "https://jooinn.com/images/man-31.jpg"
    },
    {
      "name": "Zheyuan Chen",
      "AvailableDay": "Mon Tues Wed Fri",
      "img": "https://cdn.images.express.co.uk/img/dynamic/109/590x/world-smile-day-top-facts-about-smiling-863001.jpg"
    }
  ]
export default guide;