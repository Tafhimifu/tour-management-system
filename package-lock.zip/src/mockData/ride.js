var ride =[
    {"image":"https://i.imgur.com/BW3sEUU.jpg"},{"image":"https://i.imgur.com/yo5FQ1B.jpg"},{"image":"https://i.imgur.com/aSHLrAl.jpg"},{"image":"https://i.imgur.com/kUxRzjE.jpg"}

]
export default ride;