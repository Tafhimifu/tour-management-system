import React from 'react';

const About = () => {
    return (
        <div>
            <h2>About Us </h2>
            <p>We are a little team who are continuously working to help those people who visit Cumilla.We have our guide and riders to help you.Personally we do not reference any resturant or hotel to for going. </p>
        </div>
    );
};

export default About;